# Gemini AI Liquid Glass Workspace Starter Kit

Starter Node.js + `@google/genai` SDK kèm giao diện web Apple Liquid Glass và Server Proxy (`/api/ai`) giữ bí mật API key an toàn ở backend.

## Chạy nhanh
```bash
cp .env.example .env
npm install && npm run dev
```
