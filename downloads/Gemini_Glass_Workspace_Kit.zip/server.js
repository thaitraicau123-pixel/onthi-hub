import express from 'express';
import { GoogleGenAI } from '@google/genai';

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public'));

app.post('/api/ai', async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(503).json({ ok: false, message: 'Missing GEMINI_API_KEY in .env' });
  const prompt = String(req.body?.prompt || '').trim();
  if (!prompt) return res.status(400).json({ ok: false, message: 'Empty prompt' });
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt
    });
    res.json({ ok: true, text: response.text || '' });
  } catch (err) {
    res.status(502).json({ ok: false, message: err?.message || 'AI error' });
  }
});

app.listen(Number(process.env.PORT) || 3000, () => {
  console.log('Gemini Glass Workspace listening on port', process.env.PORT || 3000);
});
