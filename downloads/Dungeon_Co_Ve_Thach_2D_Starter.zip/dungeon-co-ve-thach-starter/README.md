# Dungeon Cổ Vệ Thạch 2D Starter Kit

Full source HTML5 Canvas 2D Action RPG kèm sprite sheet (`assets/*.png`), bảng thông số (`sprite-data.json`) và dữ liệu âm thanh (`sound-data.json`).

## Chạy nhanh
```bash
npx serve . -l 3000
```
