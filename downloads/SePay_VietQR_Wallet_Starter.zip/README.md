# SePay VietQR & Ví Xu SaaS Starter Kit

Bộ kiến trúc mẫu tích hợp cổng thanh toán tự động VietQR + SePay Webhook + Bảo vệ tải file `/api/download`.

## Thiết lập nhanh
1. Copy `.env.example` thành `.env` và điền thông tin tài khoản của bạn.
2. `npm install && npm run dev`
