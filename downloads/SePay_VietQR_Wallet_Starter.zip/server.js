import express from 'express';
import { extractTopupMemo, buildVietQRUrl } from './lib/sepay.js';

const app = express();
app.use(express.json());

const intents = new Map();
const wallets = new Map();

app.post('/api/intent', (req, res) => {
  const { email, amount } = req.body || {};
  if (!email || !amount) return res.status(400).json({ ok: false, message: 'Missing email or amount' });
  const memo = 'NAP' + Math.random().toString(36).slice(2, 10).toUpperCase();
  intents.set(memo, { email: String(email).toLowerCase(), amount: Number(amount), status: 'pending' });
  const qrUrl = buildVietQRUrl({
    account: process.env.BANK_ACCOUNT || '0000000000',
    amount,
    memo
  });
  res.json({ ok: true, memo, qrUrl });
});

app.post('/api/sepay-webhook', (req, res) => {
  const auth = String(req.headers.authorization || '');
  const expected = process.env.SEPAY_WEBHOOK_SECRET || '';
  if (expected && auth !== `Apikey ${expected}`) {
    return res.status(401).json({ ok: false });
  }
  const memo = extractTopupMemo(req.body?.content || req.body?.description);
  const intent = intents.get(memo);
  if (!intent || intent.status === 'completed') return res.json({ ok: true, ignored: true });
  const amount = Number(req.body?.transferAmount) || 0;
  if (amount >= intent.amount) {
    intent.status = 'completed';
    wallets.set(intent.email, (wallets.get(intent.email) || 0) + amount);
  }
  res.json({ ok: true });
});

app.listen(Number(process.env.PORT) || 3000, () => {
  console.log('SePay VietQR Starter listening on port', process.env.PORT || 3000);
});
