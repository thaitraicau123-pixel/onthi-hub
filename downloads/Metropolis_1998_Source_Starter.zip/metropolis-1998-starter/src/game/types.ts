export type BuildingKind =
  | 'road'
  | 'park'
  | 'cottage'
  | 'townhouse'
  | 'apartment'
  | 'villa'
  | 'cafe'
  | 'diner'
  | 'supermarket'
  | 'cinema'
  | 'office'
  | 'police'
  | 'hospital'
  | 'powerplant';

export type ToolId = 'inspect' | BuildingKind | 'bulldoze';
export type InteriorTheme = 'classic' | 'warm' | 'metro';
export type TaxRate = 'low' | 'standard' | 'high';
export type WeatherKind = 'clear' | 'rain' | 'snow';
export type WeatherPreset = 'auto' | WeatherKind;
export type TimePreset = 'auto' | 'day' | 'dusk' | 'night';

export interface BuildingDef {
  kind: BuildingKind;
  name: string;
  shortName: string;
  shortDesc: string;
  cost: number;
  upgradeCost: number;
  upgradeName: string;
  hotkey: string;
  category: 'civic' | 'infra' | 'residential' | 'commercial';
  residents: number;
  jobs: number;
  power: number;
  dailyUpkeep: number;
  dailyRevenueBase: number;
  color: string;
  roofColor: string;
  height: number;
  safetyBonus?: number;
  healthBonus?: number;
}

export interface Milestone {
  id: string;
  title: string;
  targetPop: number;
  reward: number;
  completed: boolean;
}

export interface SelectedBuildingInfo {
  x: number;
  z: number;
  kind: BuildingKind;
  interiorLevel: 1 | 2 | 3;
  interiorTheme: InteriorTheme;
  powered: boolean;
  occupants: number;
  dailyRevenue: number;
}

export interface CityMetrics {
  funds: number;
  population: number;
  jobs: number;
  powerSupply: number;
  powerDemand: number;
  happiness: number;
  safety: number;
  health: number;
  dailyNet: number;
  day: number;
  timeOfDay: number;
  demandRes: number;
  demandCom: number;
  demandCivic: number;
  buildingCount: number;
  taxRate: TaxRate;
  activeVehicles: number;
  activeCitizens: number;
  weather: WeatherKind;
}

export interface HudSnapshot {
  screen: 'title' | 'playing' | 'paused' | 'gameover';
  outcome: 'victory' | 'bankrupt' | null;
  metrics: CityMetrics;
  activeTool: ToolId;
  cutaway: boolean;
  simSpeed: 0 | 1 | 2 | 4;
  timePreset: TimePreset;
  weatherPreset: WeatherPreset;
  selectedBuilding: SelectedBuildingInfo | null;
  selectedIndoorSummary: string[];
  milestones: Milestone[];
  lastEventBanner: string | null;
  endlessMode: boolean;
  muted: boolean;
  hasSavedCity: boolean;
}
