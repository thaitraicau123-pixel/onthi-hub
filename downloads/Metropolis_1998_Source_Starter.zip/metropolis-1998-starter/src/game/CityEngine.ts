import * as THREE from 'three';
import { BUILDING_CATALOG, GRID_SIZE, INITIAL_MILESTONES, STARTING_FUNDS, VICTORY_HAPPINESS, VICTORY_POPULATION } from './catalog';
import type { BuildingKind, HudSnapshot, InteriorTheme, Milestone, SelectedBuildingInfo, TaxRate, TimePreset, ToolId, WeatherKind, WeatherPreset } from './types';

interface TileSlot {
  x: number;
  z: number;
  kind: BuildingKind;
  rotation: number;
  interiorLevel: 1 | 2 | 3;
  interiorTheme: InteriorTheme;
  group: THREE.Group;
  roofMesh?: THREE.Object3D;
  interiorGroup?: THREE.Group;
}

const SAVE_KEY = 'metropolis_1998_save_v1';

export class CityEngine {
  private container: HTMLElement;
  private onSnapshot: (s: HudSnapshot) => void;
  private scene: THREE.Scene;
  private camera: THREE.OrthographicCamera;
  private renderer: THREE.WebGLRenderer;
  private ambientLight: THREE.AmbientLight;
  private sunLight: THREE.DirectionalLight;
  private weatherPoints: THREE.Points | null = null;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private tiles = new Map<string, TileSlot>();
  private gridGroup = new THREE.Group();
  private cityGroup = new THREE.Group();
  private groundPlane: THREE.Mesh;

  private screen: HudSnapshot['screen'] = 'title';
  private outcome: HudSnapshot['outcome'] = null;
  private activeTool: ToolId = 'inspect';
  private cutaway = false;
  private simSpeed: 0 | 1 | 2 | 4 = 1;
  private timePreset: TimePreset = 'auto';
  private weatherPreset: WeatherPreset = 'auto';
  private funds = STARTING_FUNDS;
  private day = 1;
  private timeOfDay = 0.38;
  private taxRate: TaxRate = 'standard';
  private placementRotation = 0;
  private camAngle = Math.PI / 4;
  private camZoom = 1;
  private camTarget = new THREE.Vector3(0, 0, 0);
  private selectedKey: string | null = null;
  private milestones: Milestone[] = INITIAL_MILESTONES.map((m) => ({ ...m }));
  private lastEventBanner: string | null = null;
  private endlessMode = false;
  private muted = false;
  private rafId = 0;
  private lastTime = performance.now();
  private dayAccumulator = 0;
  private keys = new Set<string>();
  private disposed = false;

  constructor(container: HTMLElement, onSnapshot: (s: HudSnapshot) => void, autostart = false) {
    this.container = container;
    this.onSnapshot = onSnapshot;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#9ec49b');

    const aspect = Math.max(container.clientWidth, 1) / Math.max(container.clientHeight, 1);
    const frustum = 14;
    this.camera = new THREE.OrthographicCamera(-frustum * aspect, frustum * aspect, frustum, -frustum, 0.1, 160);
    this.updateCameraTransform();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(this.renderer.domElement);

    this.ambientLight = new THREE.AmbientLight('#ffffff', 0.72);
    this.scene.add(this.ambientLight);
    this.sunLight = new THREE.DirectionalLight('#fff4d8', 1.15);
    this.sunLight.position.set(16, 26, 12);
    this.sunLight.castShadow = true;
    this.scene.add(this.sunLight);

    const groundGeo = new THREE.BoxGeometry(GRID_SIZE * 2, 0.5, GRID_SIZE * 2);
    const groundMat = new THREE.MeshLambertMaterial({ color: '#8ab884' });
    this.groundPlane = new THREE.Mesh(groundGeo, groundMat);
    this.groundPlane.position.y = -0.25;
    this.groundPlane.receiveShadow = true;
    this.scene.add(this.groundPlane);

    const gridHelper = new THREE.GridHelper(GRID_SIZE * 2, GRID_SIZE, '#5f8d5b', '#6d9d68');
    gridHelper.position.y = 0.01;
    this.gridGroup.add(gridHelper);
    this.scene.add(this.gridGroup);
    this.scene.add(this.cityGroup);

    this.buildOakwoodStarter();
    if (autostart) this.screen = 'playing';
    this.bindEvents();
    this.emitSnapshot();
    this.loop(performance.now());
  }

  private key(x: number, z: number) { return `${x},${z}`; }

  private bindEvents() {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    this.renderer.domElement.addEventListener('pointerdown', this.handlePointerDown);
    this.renderer.domElement.addEventListener('wheel', this.handleWheel, { passive: true });
  }

  private handleResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    const aspect = Math.max(w, 1) / Math.max(h, 1);
    const frustum = 14 / this.camZoom;
    this.camera.left = -frustum * aspect;
    this.camera.right = frustum * aspect;
    this.camera.top = frustum;
    this.camera.bottom = -frustum;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private handleWheel = (e: WheelEvent) => {
    this.camZoom = Math.max(0.65, Math.min(2.1, this.camZoom - e.deltaY * 0.0008));
    this.handleResize();
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    this.keys.add(k);
    if (k === 'x') this.toggleCutaway();
    else if (k === 'q') this.rotateCamera(-1);
    else if (k === 'e') this.rotateCamera(1);
    else if (k === 'r') this.rotatePlacement();
    else if (k === 'v') this.cycleWeatherPreset();
    else if (k === 'escape') {
      if (this.screen === 'playing') this.setPaused(true);
      else if (this.screen === 'paused') this.setPaused(false);
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  private handlePointerDown = (e: PointerEvent) => {
    if (this.screen !== 'playing') return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.pointer, this.camera);

    const hits = this.raycaster.intersectObject(this.groundPlane);
    if (!hits.length) return;
    const p = hits[0].point;
    const gx = Math.floor((p.x + GRID_SIZE) / 2);
    const gz = Math.floor((p.z + GRID_SIZE) / 2);
    if (gx < 0 || gx >= GRID_SIZE || gz < 0 || gz >= GRID_SIZE) return;

    const k = this.key(gx, gz);
    if (this.activeTool === 'inspect') {
      this.selectedKey = this.tiles.has(k) ? k : null;
      this.emitSnapshot();
      return;
    }
    if (this.activeTool === 'bulldoze') {
      const existing = this.tiles.get(k);
      if (existing) {
        this.funds += Math.round(BUILDING_CATALOG[existing.kind].cost * 0.25);
        this.cityGroup.remove(existing.group);
        this.tiles.delete(k);
        if (this.selectedKey === k) this.selectedKey = null;
        this.emitSnapshot();
      }
      return;
    }
    if (!this.tiles.has(k)) {
      const def = BUILDING_CATALOG[this.activeTool];
      if (this.funds >= def.cost) {
        this.funds -= def.cost;
        this.placeBuilding(gx, gz, this.activeTool, this.placementRotation);
        this.emitSnapshot();
      } else {
        this.lastEventBanner = 'Insufficient Treasury funds for ' + def.name;
        this.emitSnapshot();
      }
    }
  };

  private placeBuilding(x: number, z: number, kind: BuildingKind, rotation = 0, interiorLevel: 1 | 2 | 3 = 1, interiorTheme: InteriorTheme = 'classic') {
    const def = BUILDING_CATALOG[kind];
    const group = new THREE.Group();
    const wx = x * 2 - GRID_SIZE + 1;
    const wz = z * 2 - GRID_SIZE + 1;
    group.position.set(wx, 0, wz);
    group.rotation.y = rotation * (Math.PI / 2);

    const slot: TileSlot = { x, z, kind, rotation, interiorLevel, interiorTheme, group };

    if (kind === 'road') {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.96, 0.08, 1.96), new THREE.MeshLambertMaterial({ color: def.color }));
      mesh.position.y = 0.04;
      group.add(mesh);
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.09, 0.9), new THREE.MeshLambertMaterial({ color: '#fde68a' }));
      stripe.position.y = 0.045;
      group.add(stripe);
    } else if (kind === 'park') {
      const lawn = new THREE.Mesh(new THREE.BoxGeometry(1.88, 0.08, 1.88), new THREE.MeshLambertMaterial({ color: '#74b85e' }));
      lawn.position.y = 0.04;
      group.add(lawn);
      const tree = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.1, 6), new THREE.MeshLambertMaterial({ color: '#3b8241' }));
      tree.position.set(-0.35, 0.72, -0.2);
      group.add(tree);
    } else {
      const shell = new THREE.Mesh(
        new THREE.BoxGeometry(1.64, def.height, 1.64),
        new THREE.MeshLambertMaterial({ color: def.color }),
      );
      shell.position.y = def.height / 2;
      shell.castShadow = true;
      shell.receiveShadow = true;
      group.add(shell);

      const roof = new THREE.Mesh(
        new THREE.BoxGeometry(1.74, 0.24, 1.74),
        new THREE.MeshLambertMaterial({ color: def.roofColor }),
      );
      roof.position.y = def.height + 0.12;
      roof.visible = !this.cutaway;
      group.add(roof);
      slot.roofMesh = roof;

      const interior = new THREE.Group();
      const floorColor = interiorTheme === 'warm' ? '#f5d0a9' : interiorTheme === 'metro' ? '#cbd5e1' : '#e5d4b7';
      const floorMesh = new THREE.Mesh(new THREE.BoxGeometry(1.42, 0.1, 1.42), new THREE.MeshLambertMaterial({ color: floorColor }));
      floorMesh.position.y = 0.16;
      interior.add(floorMesh);
      for (let i = 0; i < interiorLevel; i++) {
        const desk = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.28, 0.36), new THREE.MeshLambertMaterial({ color: i === 0 ? '#92400e' : '#3b82f6' }));
        desk.position.set(-0.38 + i * 0.38, 0.34, 0);
        interior.add(desk);
      }
      interior.visible = this.cutaway;
      group.add(interior);
      slot.interiorGroup = interior;
    }

    this.cityGroup.add(group);
    this.tiles.set(this.key(x, z), slot);
  }

  private buildOakwoodStarter() {
    this.clearCity();
    for (let x = 5; x <= 10; x++) this.placeBuilding(x, 7, 'road');
    for (let z = 6; z <= 9; z++) this.placeBuilding(7, z, 'road');
    this.placeBuilding(6, 5, 'powerplant');
    this.placeBuilding(5, 6, 'cottage');
    this.placeBuilding(6, 6, 'cottage');
    this.placeBuilding(8, 6, 'diner');
    this.placeBuilding(9, 6, 'apartment');
    this.placeBuilding(8, 8, 'supermarket');
    this.placeBuilding(10, 8, 'office');
    this.placeBuilding(6, 8, 'park');
  }

  private clearCity() {
    this.tiles.forEach((t) => this.cityGroup.remove(t.group));
    this.tiles.clear();
    this.selectedKey = null;
  }

  private updateCameraTransform() {
    const r = 24;
    this.camera.position.set(
      this.camTarget.x + Math.cos(this.camAngle) * r,
      20,
      this.camTarget.z + Math.sin(this.camAngle) * r,
    );
    this.camera.lookAt(this.camTarget);
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    const dt = Math.min((now - this.lastTime) / 1000, 0.1);
    this.lastTime = now;

    if (this.screen === 'playing') {
      const panSpeed = 12 * dt;
      if (this.keys.has('w') || this.keys.has('arrowup')) this.camTarget.z -= panSpeed;
      if (this.keys.has('s') || this.keys.has('arrowdown')) this.camTarget.z += panSpeed;
      if (this.keys.has('a') || this.keys.has('arrowleft')) this.camTarget.x -= panSpeed;
      if (this.keys.has('d') || this.keys.has('arrowright')) this.camTarget.x += panSpeed;
      this.updateCameraTransform();

      if (this.simSpeed > 0) {
        this.dayAccumulator += dt * this.simSpeed;
        this.timeOfDay = (this.timeOfDay + dt * 0.015 * this.simSpeed) % 1;
        if (this.dayAccumulator >= 8) {
          this.dayAccumulator = 0;
          this.advanceDay();
        }
      }
    }

    this.applyAtmosphere();
    this.renderer.render(this.scene, this.camera);
    this.rafId = requestAnimationFrame(this.loop);
  };

  private applyAtmosphere() {
    const isNight = this.timePreset === 'night' || (this.timePreset === 'auto' && (this.timeOfDay < 0.22 || this.timeOfDay > 0.78));
    const isDusk = this.timePreset === 'dusk';
    if (isNight) {
      this.scene.background = new THREE.Color('#0f1a1c');
      this.ambientLight.intensity = 0.42;
      this.sunLight.intensity = 0.45;
    } else if (isDusk) {
      this.scene.background = new THREE.Color('#4a5568');
      this.ambientLight.intensity = 0.56;
      this.sunLight.intensity = 0.8;
    } else {
      this.scene.background = new THREE.Color('#9ec49b');
      this.ambientLight.intensity = 0.74;
      this.sunLight.intensity = 1.15;
    }
  }

  private advanceDay() {
    const snap = this.computeMetrics();
    this.day += 1;
    this.funds += snap.dailyNet;
    for (const m of this.milestones) {
      if (!m.completed && snap.population >= m.targetPop) {
        m.completed = true;
        this.funds += m.reward;
        this.lastEventBanner = `Milestone Complete: ${m.title} (+$${m.reward})`;
      }
    }
    if (!this.endlessMode && snap.population >= VICTORY_POPULATION && snap.happiness >= VICTORY_HAPPINESS) {
      this.screen = 'gameover';
      this.outcome = 'victory';
    } else if (this.funds < -500) {
      this.screen = 'gameover';
      this.outcome = 'bankrupt';
    }
    this.emitSnapshot();
  }

  private computeMetrics() {
    let population = 0;
    let jobs = 0;
    let powerSupply = 0;
    let powerDemand = 0;
    let dailyNet = 0;
    let safety = 72;
    let health = 72;
    let parkBoost = 0;
    const mult = this.taxRate === 'low' ? 0.75 : this.taxRate === 'high' ? 1.3 : 1;

    this.tiles.forEach((t) => {
      const d = BUILDING_CATALOG[t.kind];
      population += d.residents + (t.interiorLevel - 1) * (d.residents > 0 ? 4 : 0);
      jobs += d.jobs;
      if (d.power >= 0) powerSupply += d.power * t.interiorLevel;
      else powerDemand += Math.abs(d.power);
      dailyNet += Math.round(d.dailyRevenueBase * mult * (1 + (t.interiorLevel - 1) * 0.25)) - d.dailyUpkeep;
      if (d.safetyBonus) safety += d.safetyBonus;
      if (d.healthBonus) health += d.healthBonus;
      if (t.kind === 'park') parkBoost += 6;
    });

    const taxPenalty = this.taxRate === 'high' ? -12 : this.taxRate === 'low' ? 8 : 0;
    const powerPenalty = powerDemand > powerSupply ? -22 : 0;
    const happiness = Math.max(15, Math.min(100, 78 + parkBoost + taxPenalty + powerPenalty));
    const effectiveWeather: WeatherKind = this.weatherPreset === 'auto' ? 'clear' : this.weatherPreset;

    return {
      funds: this.funds,
      population,
      jobs,
      powerSupply,
      powerDemand,
      happiness,
      safety: Math.min(100, safety),
      health: Math.min(100, health),
      dailyNet,
      day: this.day,
      timeOfDay: this.timeOfDay,
      demandRes: Math.max(-50, Math.min(100, jobs - population + 20)),
      demandCom: Math.max(-50, Math.min(100, population - jobs + 15)),
      demandCivic: Math.max(-50, Math.min(100, 35 - parkBoost)),
      buildingCount: this.tiles.size,
      taxRate: this.taxRate,
      activeVehicles: Math.min(18, Math.max(2, Math.floor(this.tiles.size / 2))),
      activeCitizens: Math.min(48, Math.max(6, Math.floor(population / 2))),
      weather: effectiveWeather,
    };
  }

  private emitSnapshot() {
    const metrics = this.computeMetrics();
    const sel = this.selectedKey ? this.tiles.get(this.selectedKey) ?? null : null;
    const selectedBuilding: SelectedBuildingInfo | null = sel
      ? {
          x: sel.x,
          z: sel.z,
          kind: sel.kind,
          interiorLevel: sel.interiorLevel,
          interiorTheme: sel.interiorTheme,
          powered: metrics.powerSupply >= metrics.powerDemand,
          occupants: BUILDING_CATALOG[sel.kind].residents || BUILDING_CATALOG[sel.kind].jobs,
          dailyRevenue: BUILDING_CATALOG[sel.kind].dailyRevenueBase - BUILDING_CATALOG[sel.kind].dailyUpkeep,
        }
      : null;

    this.onSnapshot({
      screen: this.screen,
      outcome: this.outcome,
      metrics,
      activeTool: this.activeTool,
      cutaway: this.cutaway,
      simSpeed: this.simSpeed,
      timePreset: this.timePreset,
      weatherPreset: this.weatherPreset,
      selectedBuilding,
      selectedIndoorSummary: sel && sel.kind !== 'road' ? ['Desk #1 Active', 'Lighting Warm', 'Air Flow Good', 'Shift Ready'] : [],
      milestones: this.milestones.map((m) => ({ ...m })),
      lastEventBanner: this.lastEventBanner,
      endlessMode: this.endlessMode,
      muted: this.muted,
      hasSavedCity: Boolean(localStorage.getItem(SAVE_KEY)),
    });
  }

  startGame() { this.screen = 'playing'; this.emitSnapshot(); }
  resetCity(starter: boolean) {
    this.funds = STARTING_FUNDS;
    this.day = 1;
    this.outcome = null;
    this.milestones = INITIAL_MILESTONES.map((m) => ({ ...m }));
    if (starter) this.buildOakwoodStarter(); else this.clearCity();
    this.screen = 'playing';
    this.emitSnapshot();
  }
  setTool(t: ToolId) { this.activeTool = t; this.emitSnapshot(); }
  toggleCutaway() {
    this.cutaway = !this.cutaway;
    this.tiles.forEach((slot) => {
      if (slot.roofMesh) slot.roofMesh.visible = !this.cutaway;
      if (slot.interiorGroup) slot.interiorGroup.visible = this.cutaway;
    });
    this.emitSnapshot();
  }
  cycleTimePreset() {
    const order: TimePreset[] = ['auto', 'day', 'dusk', 'night'];
    this.timePreset = order[(order.indexOf(this.timePreset) + 1) % order.length];
    this.emitSnapshot();
  }
  cycleWeatherPreset() {
    const order: WeatherPreset[] = ['auto', 'clear', 'rain', 'snow'];
    this.weatherPreset = order[(order.indexOf(this.weatherPreset) + 1) % order.length];
    this.emitSnapshot();
  }
  setSimSpeed(s: 0 | 1 | 2 | 4) { this.simSpeed = s; this.emitSnapshot(); }
  rotatePlacement() { this.placementRotation = (this.placementRotation + 1) % 4; }
  rotateCamera(d: -1 | 1) { this.camAngle += d * (Math.PI / 4); this.updateCameraTransform(); }
  toggleMute() { this.muted = !this.muted; this.emitSnapshot(); }
  setPaused(p: boolean) { this.screen = p ? 'paused' : 'playing'; this.emitSnapshot(); }
  upgradeSelectedBuilding() {
    const sel = this.selectedKey ? this.tiles.get(this.selectedKey) : null;
    if (!sel || sel.interiorLevel >= 3) return;
    const cost = BUILDING_CATALOG[sel.kind].upgradeCost;
    if (this.funds < cost) return;
    this.funds -= cost;
    const nextLvl = (sel.interiorLevel + 1) as 1 | 2 | 3;
    const { x, z, kind, rotation, interiorTheme } = sel;
    this.cityGroup.remove(sel.group);
    this.placeBuilding(x, z, kind, rotation, nextLvl, interiorTheme);
    this.emitSnapshot();
  }
  setSelectedBuildingTheme(theme: InteriorTheme) {
    const sel = this.selectedKey ? this.tiles.get(this.selectedKey) : null;
    if (!sel) return;
    const { x, z, kind, rotation, interiorLevel } = sel;
    this.cityGroup.remove(sel.group);
    this.placeBuilding(x, z, kind, rotation, interiorLevel, theme);
    this.emitSnapshot();
  }
  bulldozeSelectedBuilding() {
    if (!this.selectedKey) return;
    const sel = this.tiles.get(this.selectedKey);
    if (!sel) return;
    this.funds += Math.round(BUILDING_CATALOG[sel.kind].cost * 0.25);
    this.cityGroup.remove(sel.group);
    this.tiles.delete(this.selectedKey);
    this.selectedKey = null;
    this.emitSnapshot();
  }
  clearSelection() { this.selectedKey = null; this.emitSnapshot(); }
  setTaxPolicy(rate: TaxRate) { this.taxRate = rate; this.emitSnapshot(); }
  saveCityToStorage() {
    const data = {
      funds: this.funds,
      day: this.day,
      tiles: Array.from(this.tiles.values()).map((t) => ({ x: t.x, z: t.z, kind: t.kind, rotation: t.rotation, interiorLevel: t.interiorLevel, interiorTheme: t.interiorTheme })),
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    this.lastEventBanner = 'City layout saved to browser storage';
    this.emitSnapshot();
  }
  loadCityFromStorage() {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return;
    const data = JSON.parse(raw);
    this.clearCity();
    this.funds = data.funds ?? STARTING_FUNDS;
    this.day = data.day ?? 1;
    (data.tiles || []).forEach((t: any) => this.placeBuilding(t.x, t.z, t.kind, t.rotation, t.interiorLevel, t.interiorTheme));
    this.screen = 'playing';
    this.emitSnapshot();
  }
  returnToTitle() { this.screen = 'title'; this.emitSnapshot(); }
  continueEndless() { this.endlessMode = true; this.screen = 'playing'; this.emitSnapshot(); }
  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    this.renderer.domElement.removeEventListener('pointerdown', this.handlePointerDown);
    this.renderer.domElement.removeEventListener('wheel', this.handleWheel);
    this.renderer.dispose();
  }
}
