# Metropolis 1998 — Starter Source Kit

Toi da dong goi toan bo ma nguon React 19 + TypeScript + Three.js de ban tai ve va tiep tuc phat trien ngay tren may tinh.

## Cai dat nhanh (3 buoc)
1. Giai nen file Metropolis_1998_Source_Starter.zip vao mot thu muc moi.
2. Mo Terminal tai thu muc do va chay: npm install
3. Khoi chay ban dev local: npm run dev

## Cau truc thu muc
- src/App.tsx: Root layout va dong bo snapshot giua CityEngine WebGL va React HUD.
- src/components/TitleOverlay.tsx: Man hinh chao Oakwood / Blank Parcel.
- src/components/GameHud.tsx: Top telemetry bar, Interior Cutaway, Day/Night/Weather controls, Build Dock.
- src/components/StatusModal.tsx: Modal Pause, Charter Milestones, Victory & Bankrupt.
- src/components/Icons.tsx: Bo icon SVG isometric thu cong khong can asset ngoai.
- src/game/types.ts & catalog.ts: Type definitions & thong so 14 loai cong trinh.
- src/game/CityEngine.ts: Three.js Orthographic isometric engine + cutaway renderer.
