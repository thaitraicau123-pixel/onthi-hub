# Open-Design Starter Kit (Free 0 Xu — Bùi Thái AI Studio)

Bộ starter miễn phí giúp bạn khởi tạo giao diện Apple Liquid Glass + Obsidian + Sapphire nhanh trong 1 phút.

## Bao gồm
- `.cursorrules` — Bộ quy tắc thiết kế Zero-Pill, tabular-nums, Liquid Glass tokens cho Cursor / Claude.
- `liquid-glass-tokens.css` — Biến CSS chuẩn Dark/Light Mode.
- `index.html` — Trang khung Zero-Build mở trực tiếp trên trình duyệt.

Chạy ngay: mở `index.html` hoặc `npx serve .`
